# Plan

1. Set up Wordpress stuff (install themes, plugins).
2. Create unstyled header, footer and post templates.
3. Insert placeholder content into CMS via Dashboard.
4. Create general styles across all templates.
5. Refine each template.
6. Create landing blog listing page.
7. Create user types and users.



# Credentials

## Admin

Username: `admin`

Password: `password`

## Chief Editor

Username: `ChiefEditor`

Password: `password`

## Editor

Username: `pranav`

Password: `password`