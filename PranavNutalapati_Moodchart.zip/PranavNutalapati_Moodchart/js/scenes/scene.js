// A super class for all scenes in the app
export class Scene {
  constructor(el) {
    this.el = $(el)
  }

  load() {
    this.el.css('z-index', 2).addClass("show")
  }
  unload() {
    this.el.css('z-index', 1).removeClass('show')
  }
}