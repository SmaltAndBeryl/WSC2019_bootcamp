import { Scene } from "./scene.js";
import "../create/main.js";

export class CreateScene extends Scene {
  constructor() {
    super('#create')
  }
  load() {
    super.load()
    $("#toggle-view").text('History')
    // createEngine.load('link', ['😂', '😄'])
    createEngine.load('select')
  }
}