import { Scene } from "./scene.js";

export class HistoryScene extends Scene {
  constructor() {
    super("#history");
    $("#history__clear").on('click', () => {
      localStorage.moods = '';
      engine.load('history')
    })
  }
  load() {
    super.load();
    $("#toggle-view").text('Create New')

    const moods = JSON.parse(localStorage.moods || '[]')

    if (moods.length == 0) {
      $("#entries, #history__clear").hide()
      $("#error-message").show()
    } else {
      $("#entries, #history__clear").show()
      $("#entries").empty()
      $("#error-message").hide()
    }

    moods.reverse()
    
    moods.forEach((mood) => {
      const elem = $("<div>")
      elem.append($("<span>")
        .addClass('time')
        .text(mood.time)
      )
      elem.append($("<div>")
        .append($("<img>").attr('src', mood.em1).addClass('image-1'))
        .append($("<img>").attr('src', 'imgs/arrow.png').addClass('arrow'))
        .append($("<img>").attr('src', mood.em2).addClass('image-2'))
      )
      elem.appendTo('#entries')
    })
  }
}