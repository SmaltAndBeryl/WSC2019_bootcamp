// A basic state machine
export class Engine {
  constructor(scenes, initial, args) {
    this.scenes = scenes
    this.load(initial, ...args)
  }
  // Switch to a new scene
  load(scene, ...args) {
    // if (this.currentScene === this.scenes[scene])
      // console.warn('Tried to load the current scene again')
      
    // Unload the current scene
    if (this.currentScene) {
      this.currentScene.unload()
    }
    // Load the next
    this.current = scene
    this.currentScene = this.scenes[scene]
    this.currentScene.load(...args)
  }
}