import { Scene } from "../../scenes/scene.js";
import { Engine } from "../../engine.js";

export class LinkBothScene extends Scene {
  constructor() {
    super("#link-both")
    this.em1 = $("#emoji-1")[0];
    this.em1Ctx = this.em1.getContext('2d')
    this.em2 = $("#emoji-2")[0];
    this.em2Ctx = this.em2.getContext('2d')
    this.arrow = $("#arrow-canvas")[0];

    this.arrow.width = 360
    this.arrow.height = 120
    
    this.arrowCtx = this.arrow.getContext('2d')

    this.em1.width = this.em1.height = this.em2.width = this.em2.height = 80

    this.arrowCtx.strokeStyle = 'rgb(113, 90, 156)'
    this.arrowCtx.lineWidth = 5

    $("#emoji-1").on('mousedown', this.startDragging(0).bind(this))
    $("#emoji-2").on('mousedown', this.startDragging(1).bind(this))

    $("#emoji-1").on('mouseup', this.stopDragging(0).bind(this))
    $("#emoji-2").on('mouseup', this.stopDragging(1).bind(this))

    $("#link-window").on('mousemove', this.mouseMove.bind(this))
    $("#link-window").on('mouseup mouseleave', this.mouseUp.bind(this))

    $("#link-both__save").on('click', this.save.bind(this))
  }
  
  load(emojis) {
    $("#breadcrumbs").find('div').removeClass("current completed")
    $("#breadcrumbs").find('[data-step=1]').addClass("completed")
    $("#breadcrumbs").find('[data-step=2]').addClass("current")
    $("#link-both__save").prop('disabled', true)
    super.load()
    const [ first, second ] = emojis;

    this.direction = undefined
    this.dragging = false
    this.from = null
    this.arrowCtx.clearRect(0, 0, 360, 120)

    $("#link-window").removeClass("grabbing")

    this.drawToCanvas(this.em1Ctx, first)
    this.drawToCanvas(this.em2Ctx, second)
  }

  drawToCanvas(ctx, em) {
    if (!(ctx instanceof CanvasRenderingContext2D)) return

    ctx.clearRect(0,0,80,80)
    if (typeof em == "string") {
      // Isa string
      ctx.font = "80px Arial";
      ctx.fillText(em, 0, 75)
    } else {
      // Isa image
      ctx.drawImage(em, 0, 0, 80, 80)
    }
  }

  startDragging(em) {
    return (evt) => {
      this.dragging = true
      this.direction = undefined
      $("#link-both__save").prop('disabled', true)
      this.from = em
      $("#link-window").addClass("grabbing")
    }
  }

  stopDragging(em) {
    return (evt) => {
      this.mouseUp()
      this.dragging = false
      if (this.from == em)
        return // invalid
      this.direction = this.from
    }
  }

  mouseMove(evt) {
    if (!this.dragging) return
    this.arrowCtx.clearRect(0,0,360,120)

    const pos = getCoords(evt)
    
    this.arrowCtx.beginPath()
    let arrowDirection = -10;
    this.arrowCtx.moveTo(40, 60)
    if (this.from) {
      arrowDirection = 10
      this.arrowCtx.moveTo(320, 60)
    }
    this.arrowCtx.lineTo(pos[0] + arrowDirection * 2, pos[1])
    this.arrowCtx.stroke()

    this.arrowCtx.beginPath()
    this.arrowCtx.moveTo(pos[0] + arrowDirection * 3, pos[1] + 10)
    this.arrowCtx.lineTo(pos[0] + arrowDirection * 2, pos[1])
    this.arrowCtx.lineTo(pos[0] + arrowDirection * 3, pos[1] - 10)
    this.arrowCtx.stroke()
    // console.log('move')
  }
  mouseUp() {
    this.dragging = false
    $("#link-window").removeClass("grabbing")
    this.arrowCtx.clearRect(0, 0, 360, 120)
    this.drawArrow()
  }
  
  drawArrow() {
    if (this.direction === undefined) return

    $("#link-both__save").prop('disabled', false)
    this.arrowCtx.beginPath()

    let arrowDirection = -10;
    this.arrowCtx.moveTo(90, 60)
    let pos = [270, 60]
    if (this.direction) {
      arrowDirection = 10
      this.arrowCtx.moveTo(270, 60)
      pos = [90, 60]
    }
    this.arrowCtx.lineTo(...pos)
    this.arrowCtx.stroke()

    this.arrowCtx.beginPath()
    this.arrowCtx.moveTo(pos[0] + arrowDirection, pos[1] + 10)
    this.arrowCtx.lineTo(...pos)
    this.arrowCtx.lineTo(pos[0] + arrowDirection, pos[1] - 10)
    this.arrowCtx.stroke()
  }

  save() {
    let [ em1, em2 ] = [this.em1.toDataURL(), this.em2.toDataURL()];
    if (this.direction)
      [ em2, em1 ] = [ em1, em2 ]
    const state = {
      em1, em2,
      email: 'pranavnutalapati@gmail.com',
      time: new Date().toLocaleString()
    }

    localStorage.moods = JSON.stringify(JSON.parse(localStorage.moods || '[]').concat(state))
    engine.load('history')
  }
}

function getCoords(evt) {
  let { top, left } = $("#link-window").offset()
  return [evt.pageX - left, evt.pageY - top]
}