import { Scene } from "../../scenes/scene.js";

export class SelectEmojiScene extends Scene {
  constructor() {
    super("#select-emoji")
    
    this.$canvas = $("#add-canvas")
    this.canvas = this.$canvas[0]
    this.ctx = this.canvas.getContext('2d')

    this.canvas.width = this.canvas.height = 200

    this.bindCanvasEvents()

    this.emojis = {}
    this.images = [] 
    JSON.parse(localStorage.emojis || '[]').forEach((url) => this.addEmoji(url))
    
    const that = this
    $("#emoji-list .emoji").on('click', this.selectEmoji.bind(this)).each(function() {
      const emoji = $(this).attr("data-emoji");
      that.emojis[emoji] = false;
    })
    $("#select-emoji__next").on('click', function() {
      const selected = Object.keys(that.emojis).filter(e => that.emojis[e]).concat(that.images.filter(i => i.selected).map(i => i.img))
      createEngine.load('link', selected)
    })
    $("#add-emoji").on('click', this.showAddEmojiForm.bind(this))

    $("#aef-cancel, #aef-bg").on('click', () => $('#add-emoji-form').removeClass('show'))
    $("#aef-save").on('click', () => this.addEmoji())
  }

  load() {
    $("#breadcrumbs").find('div').removeClass("current completed")
    $("#breadcrumbs").find('[data-step=1]').addClass("current")
    super.load()
    Object.keys(this.emojis).forEach(k => this.emojis[k] = false)
    this.images.forEach(i => i.selected = false)
    this.updateView()
  }

  selectEmoji(event) {
    const emoji = $(event.target).attr("data-emoji");
    this.emojis[emoji] = !this.emojis[emoji]
    this.updateView()
  }

  selectImage(event) {
    const image = this.images[$(event.target).attr('data-id')]
    image.selected = !image.selected
    this.updateView()
  }

  updateView() {
    for (let [emoji, value] of Object.entries(this.emojis)) {
      $(`#emoji-list .emoji[data-emoji=${emoji}]`).toggleClass('selected', value)
    }
    this.images.forEach(({ selected }, i) => {
      $(`#emoji-list .image[data-id=${i}]`).toggleClass('selected', selected)
    })
    const selections = Object.values(this.emojis).reduce((s, a) => s + a, 0) + this.images.reduce((s, i) => s + i.selected, 0)
    if (selections < 2) {
      $("#emoji-list").removeClass('disabled')
      $("#select-emoji__next").prop('disabled', true)
    } else {
      $("#emoji-list").addClass('disabled')
      $("#select-emoji__next").prop('disabled', false)
    }
  }

  addEmoji(dataUrl = null) {
    console.log(!!dataUrl)
    if (!dataUrl) {
      dataUrl = this.canvas.toDataURL();  
      localStorage.emojis = JSON.stringify(JSON.parse(localStorage.emojis || '[]').concat(dataUrl))
    }
    const emoji = $("<div>").addClass('image');
    const id = this.images.length;
    const img = new Image
    img.src = dataUrl
    

    this.images.push({ img, selected: false })

    emoji.css('background-image', `url(${dataUrl})`)
    emoji.attr('data-id', id)
    emoji.insertAfter("#add-emoji")
    $("#add-emoji-form").removeClass('show')
    emoji.on('click', this.selectImage.bind(this))
  }

  showAddEmojiForm() {
    $("#add-emoji-form").addClass('show')
    this.ctx.save()
    this.ctx.fillStyle = "#fff";
    this.ctx.fillRect(0,0,200,200)
    this.ctx.restore()
  }
  
  bindCanvasEvents() {
    this.ctx.strokeStyle = 'rgb(113, 90, 156)'
    this.ctx.lineWidth = 5
    this.$canvas.on('mousedown', (e) => {
      this.clicking = true
      this.ctx.beginPath()
      this.ctx.moveTo(...getCoords(e))
    })
    this.$canvas.on('mousemove', (e) => {
      if (!this.clicking) return;
      this.ctx.lineTo(...getCoords(e))
      this.ctx.stroke()
    })
    this.$canvas.on('mouseup mouseleave', () => this.clicking = false)
  }
}

function getCoords(evt) {
  return [evt.offsetX, evt.offsetY]
}