import { Engine } from "../engine.js";
import { SelectEmojiScene } from "./scenes/select-emoji.js";
import { LinkBothScene } from "./scenes/link-both.js";

window.createEngine = new Engine({
  select: new SelectEmojiScene,
  link: new LinkBothScene
}, "select", [])