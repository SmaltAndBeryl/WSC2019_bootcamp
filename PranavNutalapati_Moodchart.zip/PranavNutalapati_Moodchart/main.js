import { Engine } from "./js/engine.js";
import { CreateScene } from "./js/scenes/create.js";
import { HistoryScene } from "./js/scenes/history.js";

const initial = "history",
      args = []

window.engine = new Engine({
  history: new HistoryScene,
  create: new CreateScene
}, initial, args)

$("#brand").on('click', () => engine.load(initial, ...args)) // reset to initial page
$("#toggle-view").on('click', function() {
  const target = engine.current == 'history' ? 'create' : 'history'
  engine.load(target)
})