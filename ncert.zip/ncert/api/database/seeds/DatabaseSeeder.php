<?php

use Illuminate\Database\Seeder;
use App\User;
use App\Admin;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
        $u = new User;
        $u->username = "admin";
        $u->password = Hash::make('password');

        $admin = new Admin([
            "name" => "Admin 1"
        ]);

        $admin->save();
        $admin->user()->save($u);
    }
}
