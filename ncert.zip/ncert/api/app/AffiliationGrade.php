<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AffiliationGrade extends Model
{
    protected $fillable = [
        'grade'
    ];

    //
    function affiliation()
    {
        return $this->belongsTo('App\Affiliation');
    }
}
