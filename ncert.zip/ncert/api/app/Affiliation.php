<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Affiliation extends Model
{
    //
    protected $fillable = [
        'name', 'city', 'state', 'status'
    ];

    public $appends = ['grades'];

    public $hidden = ['affiliation_grades'];

    function school()
    {
        return $this->belongsTo('App\School');
    }

    function affiliationGrades()
    {
        return $this->hasMany('App\AffiliationGrade');
    }

    function getGradesAttribute()
    {
        $f = $this->affiliationGrades;
        $this->unsetRelation('affiliationGrades');
        return $f->pluck('grade');
    }
}
