<?php
// Helpers


// All the responses from the app.
function apiresponse($message, $success, $code)
{
  return response([
    "success" => $success,
    "message" => $message
  ], $code);
}

function success($message = "Successful")
{
  return apiresponse($message, true, 200);
}

function unexpected($message = "An unexpected error occured.")
{
  return apiresponse($message, false, 500);
}

function unauthorized($message = "Unauthorized")
{
  return apiresponse($message, false, 401);
}

function forbidden($message = "Forbidden")
{
  return apiresponse($message, false, 403);
}

function unprocessable($message = "Can not process input")
{
  return apiresponse($message, false, 422);
}

function badRequest($message = "Bad request")
{
  return apiresponse($message, false, 400);
}


// format validator errors

function formatValidator($validator)
{
  return $validator->errors();
}
