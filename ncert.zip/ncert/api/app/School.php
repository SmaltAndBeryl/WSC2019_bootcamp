<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class School extends Model
{
    //
    protected $fillable = [
        'name', 'email'
    ];

    function user()
    {
        return $this->morphOne('App\User', 'authenticatable');
    }

    function affiliation()
    {
        return $this->hasOne('App\Affiliation');
    }
}
