<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

use App\School;
use App\User;

class AuthController extends Controller
{
    // Attempt to log in user from provided credentials
    function login(Request $request)
    {
        $v = Validator::make($request->all(), [
            "username" => "required", "password" => "required"
        ]);
        if ($v->fails()) {
            return unprocessable(formatValidator($v));
        }

        $user = User::whereUsername($request->username)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return unauthorized('Username or password incorrect.');
        }

        // User is valid
        $user->token = md5($user->username);
        $user->save();
        $user->load('authenticatable');
        if ($user->authenticatable_type == 'App\School')
            $user->load('authenticatable.affiliation');
        return success($user);
    }

    function logout(Request $request)
    {
        try {
            auth()->user()->token = null;
            auth()->user()->save();
            return success("Logout successful!");
        } catch (QueryException $e) {
            return unexpected();
        }
    }

    // Create and log in user.
    function register(Request $request)
    {
        $v = Validator::make($request->all(), [
            "username" => "required",
            "password" => "required",
            "name" => "required",
            "email" => "required|email"
        ]);

        if ($v->fails()) {
            return unprocessable(formatValidator($v));
        }

        try {
            $school = new School($request->only('name', 'email'));
            $school->save();
            $school->user()->create([
                "username" => $request->username,
                "password" => Hash::make($request->password),
                "token" => md5($request->username)
            ]);
        } catch (QueryException $e) {
            return unprocessable('Username or email already in use.');
        }

        return success($school->user()->with('authenticatable.affiliation')->first());
    }
}
