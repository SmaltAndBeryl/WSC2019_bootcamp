<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\School;
use App\Affiliation;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class AffiliationController extends Controller
{
    // Create an affiliation request
    function create(Request $request)
    {
        DB::beginTransaction();
        if (!$request->has('name', 'city', 'state', 'grades')) {
            return unprocessable('Fields missing.');
        }
        $school = auth()->user()->authenticatable;

        if ($school->affiliation)
            return unprocessable('Affiliation already exists!');

        $grades = array_map(function ($grade) {
            return ["grade" => $grade];
        }, array_map('trim', explode(',', $request->grades)));

        try {
            $affiliation = $school->affiliation()->create($request->only('name', 'city', 'state'));
            $affiliation->affiliationGrades()->createMany($grades);
        } catch (QueryException $e) {
            DB::rollBack();
            return unprocessable();
        }

        DB::commit();
        return success($affiliation);
    }

    // Edit an affiliation
    function update($id, Request $request)
    {
        $school = auth()->user()->authenticatable;
        $affiliation = $school->affiliation;

        if (!$affiliation)
            return unprocessable('Affiliation does not exist.');

        if ($affiliation->id != $id)
            return unauthorized('Can not edit requested affiliation.');

        if ($affiliation->status == "approved" || $affiliation->status == "rejected")
            return unprocessable('Can not edit reviewed application.');

        DB::beginTransaction();
        $affiliation->status = 'pending';

        if ($request->has('name'))
            $affiliation->name = $request->name;

        if ($request->has('city'))
            $affiliation->city = $request->city;

        if ($request->has('state'))
            $affiliation->state = $request->state;

        if ($request->has('grades')) {
            $grades = array_map(function ($grade) {
                return ["grade" => $grade];
            }, array_map('trim', explode(',', $request->grades)));

            $affiliation->affiliationGrades()->delete();
            try {
                $affiliation->affiliationGrades()->createMany($grades);
            } catch (QueryException $e) {
                DB::rollBack();
                return unprocessable();
            }
        }

        try {
            $affiliation->save();
        } catch (QueryException $e) {
            DB::rollBack();
            return unprocessable();
        }
        DB::commit();
        return success($affiliation);
    }

    // Return all pending affiliations for review
    function fetch()
    {
        return Affiliation::where('status', 'pending')->get();
    }

    // Update the status of an affiliation
    function updateStatus(Request $request, $id)
    {
        if (!$request->has('status'))
            return unprocessable('Fields missing!');

        $affiliation = Affiliation::find($id);
        if (!$affiliation)
            return unprocessable('Affiliation does not exist!');

        $affiliation->status = $request->status;
        try {
            $affiliation->save();
        } catch (QueryException $e) {
            return unprocessable();
        }
        return success('Affiliation updated successfully!');
    }
}
