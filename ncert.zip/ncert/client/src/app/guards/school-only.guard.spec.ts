import { TestBed, async, inject } from '@angular/core/testing';

import { SchoolOnlyGuard } from './school-only.guard';

describe('SchoolOnlyGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SchoolOnlyGuard]
    });
  });

  it('should ...', inject([SchoolOnlyGuard], (guard: SchoolOnlyGuard) => {
    expect(guard).toBeTruthy();
  }));
});
