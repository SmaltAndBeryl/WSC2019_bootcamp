import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent as AdminDashboardComponent } from './admin/dashboard/dashboard.component';
import { DashboardComponent as SchoolDashboardComponent } from './school/dashboard/dashboard.component';
import { AdminOnlyGuard } from './guards/admin-only.guard';
import { SchoolOnlyGuard } from './guards/school-only.guard';
import { NoAuthGuard } from './guards/no-auth.guard';

const routes: Routes = [
  { path: '', component: LoginComponent, canActivate: [NoAuthGuard] },
  { path: 'register', component: RegisterComponent, canActivate: [NoAuthGuard] },
  { path: 'admin', component: AdminDashboardComponent, canActivate: [AdminOnlyGuard] },
  { path: 'school', component: SchoolDashboardComponent, canActivate: [SchoolOnlyGuard] },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
