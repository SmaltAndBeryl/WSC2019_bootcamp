import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

const { url } = environment;

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public loggedIn$ = new BehaviorSubject<boolean>(false);
  public loggedIn: boolean;
  public user: any;

  constructor(
    private http: HttpClient,
    private router: Router
  ) {
    this.loggedIn$.subscribe(v => this.loggedIn = v);
    this.loadState()
  }

  public login(username, password): Promise<undefined> {
    return new Promise((resolve, reject) => {
      this.http.post<any>(url('auth/login'), { username, password }).subscribe(result => {
        const user = result.message;
        this.storeLogin(user);
        resolve();
      }, error => {
        reject(error.error.message)
      })
    });
  }

  public register(data): Promise<undefined> {
    return new Promise((resolve, reject) => {
      this.http.post<any>(url('auth/register'), data).subscribe(result => {
        const user = result.message;
        this.storeLogin(user);
        resolve();
      }, error => {
        reject(error.error.message);
      })
    })
  }

  public logout(): Promise<undefined> {
    return new Promise((resolve, reject) => {
      let token = this.user.token;
      this.http.post<any>(url('auth/logout', token), {}).subscribe(result => {
        this.storeLogin(null);
        this.redirect();
        resolve()
      }, error => {
        reject(error.error.message);
      })
    })
  }

  public redirect() {
    if (!this.user)
      return this.router.navigate([''])

    let type = this.user.authenticatable_type;
    if (type == 'App\\Admin')
      this.router.navigate(['admin'])
    else
      this.router.navigate(['school'])
  }

  // Persistence of credentials
  storeLogin(user: any) {
    this.user = user;
    if (user) {
      this.loggedIn$.next(true)
      this.saveState();
    } else {
      this.loggedIn$.next(false)
      this.saveState();
    }
  }

  saveState() {
    localStorage['user'] = JSON.stringify(this.user);
  }

  loadState() {
    if (!localStorage['user'])
      return

    const user = JSON.parse(localStorage['user'])
    this.storeLogin(user);
  }
}
