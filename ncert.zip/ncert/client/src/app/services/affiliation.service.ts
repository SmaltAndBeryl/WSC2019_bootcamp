import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

import { environment } from 'src/environments/environment';

const { url } = environment;

@Injectable({
  providedIn: 'root'
})
export class AffiliationService {
  public o = {
    fetch: new Subject
  }
  private token: string = null;

  constructor(
    private authService: AuthService,
    private http: HttpClient
  ) { }

  public fetch() {
    let token = this.authService.user.token;
    this.http.get(url('affiliation', token)).subscribe(result => {
      this.o.fetch.next(result)
    }, error => {
      console.log(error)
    });
  }

  public updateStatus(id, status): Promise<any> {
    let token = this.authService.user.token;
    return new Promise((resolve, reject) => {
      this.http.post(url(`affiliation/${id}/status`, token), { status }).subscribe(result => {
        resolve();
      }, error => {
        reject(error.error.message)
      });
    });
  }

  public create(details): Promise<any> {
    let token = this.authService.user.token;
    return new Promise((resolve, reject) => {
      this.http.post<any>(url('affiliation', token), details).subscribe(result => {
        resolve(result.message)
      }, error => {
        reject(error.error.message)
      })
    });
  }

  public update(id, delta): Promise<any> {
    let token = this.authService.user.token;
    return new Promise((resolve, reject) => {
      this.http.post<any>(url(`affiliation/${id}`, token), delta).subscribe(result => {
        resolve(result.message)
      }, error => {
        reject(error.error.message)
      })
    })
  }
}
