import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  public message = null;
  public loading = false;

  constructor(
    public authService: AuthService
  ) { }

  ngOnInit() {
  }

  attemptRegister(form: NgForm) {
    if (!form.valid)
      return this.message = "Please ensure all fields are filled."

    this.authService.register(form.value)
      .then(() => this.authService.redirect())
      .catch(e => this.message = e)
      .finally(() => this.loading = false);
  }
}
