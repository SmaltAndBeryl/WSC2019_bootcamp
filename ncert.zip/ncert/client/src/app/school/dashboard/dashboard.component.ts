import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { AffiliationService } from 'src/app/services/affiliation.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @ViewChild('form') form;

  public incompleteProfile = true;
  public canEdit = true;
  public school;

  constructor(
    public authService: AuthService,
    public affiliationService: AffiliationService,
    private router: Router
  ) {
    console.log("test")
    this.school = this.authService.user.authenticatable;
    this.incompleteProfile = !(this.school.affiliation && this.school.affiliation.status == "approved");
    this.canEdit = !this.school.affiliation || this.school.affiliation.status == "to_edit" || this.school.affiliation.status == "pending";
  }

  ngOnInit() {
    if (this.school.affiliation) {
      let aff = {
        name: this.school.affiliation.name,
        city: this.school.affiliation.city,
        state: this.school.affiliation.state,
        grades: this.school.affiliation.grades.join(', '),
      }
      setTimeout(() => this.form.setValue(aff))
    }
  }

  submitAffiliation(form: NgForm) {
    if (!form.valid)
      return alert("Please ensure all required fields are filled.");

    if (this.school.affiliation) {
      // update
      this.affiliationService.update(this.school.affiliation.id, form.value)
        .then((e) => {
          this.authService.user.authenticatable.affiliation = e
          this.authService.saveState();
          this.router.navigate(['.']);
        })
        .catch(e => {
          alert("Please ensure you've entered valid values.");
        })
    } else {
      // create
      this.affiliationService.create(form.value)
        .then((e) => {
          this.authService.user.authenticatable.affiliation = e
          this.authService.saveState();
          location.reload();
        })
        .catch(e => {
          alert("Please ensure you've entered valid values.");
        })
    }
  }

  nice(status) {
    switch (status) {
      case "approved":
        return "Approved";
      case "rejected":
        return "Rejected";
      case "to_edit":
        return "Needs Edits";
      case "pending":
        return "Pending";
    }
  }
}
