import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public message = null;
  public loading = false;

  constructor(
    public authService: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  attemptLogin(form: NgForm) {
    if (!form.valid)
      return this.message = "Please ensure all fields are filled.";

    const { username, password } = form.value

    this.loading = true;
    this.authService.login(username, password)
      .then(() => {
        this.authService.redirect()
      })
      .catch((e) => this.message = e)
      .finally(() => this.loading = false);
  }
}
