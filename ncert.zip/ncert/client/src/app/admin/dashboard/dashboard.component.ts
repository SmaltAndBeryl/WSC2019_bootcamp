import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { AffiliationService } from 'src/app/services/affiliation.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public affiliations = [];
  public loading = false;

  constructor(
    public authService: AuthService,
    public affiliationService: AffiliationService
  ) {
    this.affiliationService.o.fetch.subscribe((affiliations: []) => {
      this.affiliations = affiliations
    });
  }

  ngOnInit() {
    this.affiliationService.fetch();
  }

  saveStatus(affiliation, status) {
    this.loading = true;
    this.affiliationService.updateStatus(affiliation.id, status)
      .then(() => this.affiliationService.fetch())
      .catch(e => alert("An unexpected error occured: \n\n" + e))
      .finally(() => this.loading = false);
  }

}
