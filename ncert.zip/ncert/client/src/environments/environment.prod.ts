export const environment = {
  production: true,
  apiUrl: 'http://localhost/ncert/api/v1/',
  url: (path: string, token?: string): string => environment.apiUrl + path + (token ? `?token=${token}` : '')
};
