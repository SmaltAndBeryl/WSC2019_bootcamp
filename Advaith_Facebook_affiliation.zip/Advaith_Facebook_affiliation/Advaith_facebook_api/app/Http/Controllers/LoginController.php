<?php

namespace App\Http\Controllers;

use Auth;
use Response;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function login()
    {
        Auth::user()->update([
            'token' => md5(Auth::user()->email)
        ]);

        return Response::json([
            'message' => 'successfully logged in',
            'token' => Auth::user()->token,
            'user' => Auth::user()
        ]);
    }

    public function logout()
    {
        Auth::user()->update([
            'token' => null
        ]);

        return Response::json([
            'message' => 'successfully logged out'
        ]);
    }
}
