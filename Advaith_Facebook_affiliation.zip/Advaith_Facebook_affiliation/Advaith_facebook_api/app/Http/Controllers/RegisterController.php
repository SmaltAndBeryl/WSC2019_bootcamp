<?php

namespace App\Http\Controllers;

use Auth;
use Response;
use App\User;
use Validator;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => ['required', 'email', 'unique:users,email'],
            'password' => ['required'],
            'name' => ['required']
        ]);

        if ($validator->errors()->isNotEmpty())
            return Response::json([
                'message' => 'Data cannot be proccessed',
                'errors' => $validator->errors()
            ], 422);

        $user = User::create([
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'name' => $request->name,
            'token' => md5($request->email)
        ]);

        return Response::json([
            'message' => 'Successfully registered',
            'user' => $user
        ]);
    }
}
