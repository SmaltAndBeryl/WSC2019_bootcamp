<?php

namespace App\Http\Controllers;

use Auth;
use Response;
use Validator;
use Illuminate\Http\Request;

class UploadController extends Controller
{
    public function index()
    {
        return Auth::user()->uploads()->orderBy('created_at', 'DESC')->get();
    }

    public function upload(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'image' => ['required', 'image']
        ]);

        if ($validator->errors()->isNotEmpty())
            return Response::json([
                'message' => 'Data cannot be proccessed',
                'errors' => $validator->errors()
            ], 422);

        $file = $request->file('image')->store('uploads');

        Auth::user()->uploads()->create([
            'path' => $file
        ]);

        return Response::json([
            'message' => 'Successfully uploaded the image'
        ]);
    }
}
