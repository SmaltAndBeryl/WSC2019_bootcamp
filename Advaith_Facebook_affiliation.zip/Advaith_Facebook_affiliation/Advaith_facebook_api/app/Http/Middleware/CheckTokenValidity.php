<?php

namespace App\Http\Middleware;

use Auth;
use Closure;
use Response;

class CheckTokenValidity
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($request->token && $request->token === Auth::user()->token)
            return $next($request);

        return Response::json([
            'message' => 'Unauthenticated user'
        ], 401);
    }
}
