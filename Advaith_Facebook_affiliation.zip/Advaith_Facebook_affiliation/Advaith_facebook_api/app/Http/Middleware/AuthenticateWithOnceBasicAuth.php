<?php

namespace App\Http\Middleware;

use Auth;
use Closure;
use Response;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;

class AuthenticateWithOnceBasicAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        try {
            return Auth::onceBasic() ?: $next($request);
        } catch (UnauthorizedHttpException $e) {
            return Response::json([
                'message' => 'Unauthenticated user'
            ], 401);
        }
    }
}
