<?php

// requiring the main php file
require('public/index.php');
