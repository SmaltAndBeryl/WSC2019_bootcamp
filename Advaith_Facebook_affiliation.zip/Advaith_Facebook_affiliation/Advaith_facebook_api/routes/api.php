<?php

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/v1/register', 'RegisterController@register');

Route::middleware('auth.once.basic')->prefix('v1')->group(function () {
    Route::post('/login', 'LoginController@login');

    Route::middleware('token')->group(function () {
        Route::post('/logout', 'LoginController@logout');

        Route::get('/upload', 'UploadController@index');
        Route::post('/upload', 'UploadController@upload');
    });
});
