(function () {
    let flashController = function($scope, flashService) {
        $scope.type = () => flashService.type;
        $scope.content = () => flashService.content;
        $scope.display = () => flashService.display;
    }

    flashController.$inject = ['$scope', 'flashService'];

    app.controller('flashController', flashController);
})()