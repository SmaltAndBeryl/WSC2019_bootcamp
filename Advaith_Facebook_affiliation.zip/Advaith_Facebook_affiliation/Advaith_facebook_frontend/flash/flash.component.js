app.component('flash', {
    templateUrl: 'flash/flash.component.html',
    controller: 'flashController'
});