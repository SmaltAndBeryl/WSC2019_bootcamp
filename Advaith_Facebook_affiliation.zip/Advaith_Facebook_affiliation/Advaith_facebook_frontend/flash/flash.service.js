(function () {
    let flashService = function ($timeout) {
        this.type = '';
        this.content = '';
        this.display = false;
        
        this.timeout = function () {
            this.display = true;

            $timeout.cancel(this.timeoutContainer);
            this.timeoutContainer = $timeout(() => {
                this.display = false;
            }, 6000);
        }

        this.success = function (message) {
            this.type = 'success';
            this.content = message;
            this.timeout();
        }

        this.error = function (message) {
            this.type = 'error';
            this.content = message;
            this.timeout();
        }
    }

    flashService.$inject = ['$timeout'];

    app.service('flashService', flashService);
})()