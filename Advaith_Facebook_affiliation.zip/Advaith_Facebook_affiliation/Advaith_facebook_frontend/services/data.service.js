(function () {
    let dataService = function ($http) {
        this.auth = null;
        this.loggedIn = () => this.auth !== null;

        this.update = (state) => {
            this.auth = state;
            localStorage.setItem('auth', JSON.stringify(this.auth));
        }

        if (localStorage.getItem('auth'))
            this.auth = JSON.parse(localStorage.getItem('auth'));
        if (this.loggedIn())
            $http.defaults.headers.common['Authorization'] = this.auth.basic;
    }

    dataService.$inject = ['$http']

    app.service('dataService', dataService);
})()