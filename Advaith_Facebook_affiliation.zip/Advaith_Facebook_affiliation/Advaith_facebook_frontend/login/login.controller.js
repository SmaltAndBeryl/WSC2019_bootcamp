(function () {
    let loginController = function ($scope, dataService, flashService, $http, server, $location) {
        $scope.login = () => {
            let basic = `Basic ${btoa(`${$scope.email}:${$scope.password}`)}`;
            $http.defaults.headers.common['Authorization'] = basic;

            $http.post(`${server}/login`).then(({ data }) => {
                flashService.success(data.message);
                dataService.update(Object.assign({ basic }, data.user));
                $location.path('/upload');
            }).catch(({ data }) => {
                flashService.error(data.message);
            })
        }

        $scope.register = () => {
            let basic = `Basic ${btoa(`${$scope.email}:${$scope.password}`)}`;
            $http.defaults.headers.common['Authorization'] = basic;
            
            $http.post(`${server}/register`, {
                name: $scope.name,
                email: $scope.email,
                password: $scope.password
            }).then(({ data }) => {
                flashService.success(data.message);
                dataService.update(Object.assign({ basic }, data.user));
                $location.path('/upload');
            }).catch(({ data }) => {
                flashService.error(data.message);
            })
        }
    }

    loginController.$inject = ['$scope', 'dataService', 'flashService', '$http', 'server', '$location']

    app.controller('loginController', loginController);
})()