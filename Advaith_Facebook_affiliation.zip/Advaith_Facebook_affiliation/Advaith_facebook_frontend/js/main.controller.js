(function () {
    let mainController = function ($scope, flashService, dataService, $location, $http, server) {
        $scope.navbar = false;

        $scope.loggedIn = () => dataService.loggedIn();
        
        $scope.guestMiddleware = function () {
            if ($scope.loggedIn())
                $location.path('/upload')
        }

        $scope.authMiddleware = function () {
            if (!$scope.loggedIn())
                $location.path('/')
        }

        $scope.logout = function () {
            $http.post(`${server}/logout`, {
                token: dataService.auth.token
            }).then(({ data }) => {
                flashService.success(data.message);
                dataService.update(null);
                $location.path('/');
            }).catch(({ data }) => {
                flashService.error(data.message);
            })
        }
    }

    mainController.$inject = ['$scope', 'flashService', 'dataService', '$location', '$http', 'server'];

    app.controller('mainController', mainController);
})()