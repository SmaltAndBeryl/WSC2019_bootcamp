const app = angular.module('app', ['ngRoute'])

app.constant('server', 'http://localhost/Advaith_facebook_api/api/v1');