(function () {
    let router = function ($routeProvider) {
        $routeProvider.when('/', {
            templateUrl: 'login/login.view.html',
            controller: 'loginController'
        }).when('/register', {
            templateUrl: 'login/register.view.html',
            controller: 'loginController'
        }).when('/upload', {
            templateUrl: 'upload/upload.view.html',
            controller: 'uploadController'
        }).when('/uploaded', {
            templateUrl: 'upload/uploaded.view.html',
            controller: 'uploadController'
        }).otherwise({
            redirectTo: '/'
        })
    }

    router.$inject = ['$routeProvider'];
    
    app.config(router);
})()