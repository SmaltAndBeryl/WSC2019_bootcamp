(function () {
    let uploadController = function ($http, server, dataService, $scope, flashService) {
        $http.get(`${server}/upload?token=${dataService.auth.token}`).then(({ data }) => {
            $scope.images = data;
        }).catch(({ data }) => {
            flashService.error(data.message);
        })

        $scope.url = (url) => `http://localhost/Advaith_facebook_api/public/${url}`;

        $scope.upload = function () {
            let formData = new FormData();
            formData.append('image', $scope.image);
            formData.append('token', dataService.auth.token);

            $http({
                url: `${server}/upload`,
                method: 'POST',
                headers: {
                    'Content-Type': undefined
                },
                data: formData
            }).then(({ data }) => {
                flashService.success(data.message);
            }).catch(({ data }) => {
                flashService.error(data.message);
            })
        }
    }

    uploadController.$inject = ['$http', 'server', 'dataService', '$scope', 'flashService']

    app.controller('uploadController', uploadController);
})()