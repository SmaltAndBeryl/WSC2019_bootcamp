app.directive('fileUpload', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModel) {
            element.on('change', function () {
                ngModel.$setViewValue(element[0].files[0]);
            })
        }
    }
})