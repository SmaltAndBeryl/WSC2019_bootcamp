## username `admin`
## password `admin`

## URL `http://localhost/advaith_cmsexercise`